<?php
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "";
	
	$conn = mysqli_connect($servername, $username, $password, $dbname);

	// Create database --------------------------------------------------------
	$sql = "CREATE DATABASE IF NOT EXISTS panambi";

	if (mysqli_query($conn, $sql)) {
	    echo "Database created successfully<br>";
	} else {
	    echo "Error creating database: " . mysqli_error($conn) . "<br>";
	}

	$dbname = 'panambi';
	mysqli_select_db ( $conn , $dbname);

	if (!$conn) {
	    die("select db connection failed: " . mysqli_connect_error());
	}

	//create accelaration table --------------------------------------------------
	$sql = "CREATE TABLE IF NOT EXISTS `productos` (
	  `stock` VARCHAR(50) NOT NULL,
	  `precio_compra` VARCHAR(50) NOT NULL,
	  `precio_ventas` VARCHAR(50) NOT NULL,
	  `id_productos` INT NOT NULL AUTO_INCREMENT,
	  PRIMARY KEY (`id_productos`))";

	if(mysqli_query($conn, $sql)){
	    echo "Table accelaration created successfully<br>";
	} else {
	    echo "Error creating accelaration table: " . mysqli_error($conn). "<br>";
	}
			
	$query = "INSERT INTO productos (stock, precio_compra, precio_ventas) VALUES
	('1', '2'), ('4', '5') ,('3', '5'),('6', '7'),('2', '4'),('0', '3'),('3', '2')";
	
	$conn->query($query);
	mysqli_close($conn);
?>