<?php
	/* Conexion */
	$host = 'localhost';
	$user = 'root';
	$pass = '';
	$db = 'panambi';
	$mysqli = new mysqli($host,$user,$pass,$db) or die($mysqli->error);

	$data1 = '';
	$data2 = '';
	$data3 = '';


	//Obtener datos de la tabla
	$sql = "SELECT * FROM `productos` ";
    $result = mysqli_query($mysqli, $sql);

	//Recorrer los datos devueltos
	while ($row = mysqli_fetch_array($result)) {

		$data1 = $data1 . '"'. $row['stock'].'",';
		$data2 = $data2 . '"'. $row['precio_compra'] .'",';
		$data3 = $data3 . '"'. $row['precio_ventas'] .'",';
	}

	//trim() Elimina los espacios en blanco 
	$data1 = trim($data1,",");
	$data2 = trim($data2,",");
	$data3 = trim($data3,",");
?>

<!DOCTYPE html>
<html>
	<head>
    	<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.2/Chart.bundle.min.js"></script>
		<title>Grafico productos</title>

		<style type="text/css">			
			body{
				font-family: Arial;


			    color: white;
			    text-align: center;
			
			}

			.container {
				color: #E8E9EB;
				background: #222;
				border: #555652 1px solid;
				padding: 10px;
			}
		</style>

	</head>

	<body>	   
	    <div class="container">	
	    <h1>GRAFICO DE STOCK DE PRODUCTOS</h1>       
			<canvas id="chart" style="width: 100%; height: 65vh; background: #222; border: 1px solid #555652; margin-top: 10px;"></canvas>

			<script>
				var ctx = document.getElementById("chart").getContext('2d');
    			var myChart = new Chart(ctx, {
        		type: 'line',
		        data: {
		            labels: [1,2,3,4,5,6,7,8,9],
		            datasets: 
		            [{
		                label: 'Stock',
		                data: [<?php echo $data1; ?>],
		                backgroundColor: 'transparent',
		                borderColor:'rgba(255, 37, 47)',
		                borderWidth: 3
		            },

		            {
		            	label: 'Precio compra',
		                data: [<?php echo $data2; ?>],
		                backgroundColor: 'transparent',
		                borderColor:'rgba(93, 255, 63)',
		                borderWidth: 3	
		            },  
					{
		            	label: 'Precio Venta',
		                data: [<?php echo $data3; ?>],
		                backgroundColor: 'transparent',
		                borderColor:'rgba(49, 3, 241)',
		                borderWidth: 3	
		            }
				
				
				]
		        },
		     
		        options: {
		            scales: {scales:{yAxes: [{beginAtZero: false}], xAxes: [{autoskip: true, maxTicketsLimit: 20}]}},
		            tooltips:{mode: 'index'},
		            legend:{display: true, position: 'top', labels: {fontColor: 'rgb(255,255,255)', fontSize: 16}}
		        }
		    });
			</script>
	    </div>
	    
	</body>
</html>