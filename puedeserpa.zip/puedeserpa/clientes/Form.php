<div class="container">
  <br>
  <br>
  <div class="navbar navbar-default">
    <div class="panel-heading">Nuevo Clientes</div>
    <div class="panel-body">

      <form class="form-horizontal" action="clientes/nuevoCliente.php" method="POST">
        <div class="form-group">
          <label class="control-label col-sm-2" for="Descripcion">Nombre:</label>
          <div class="col-sm-10">
            <input type="Nombre" class="form-control" id="Nombre" name="Nombre" placeholder="Nombre" required>
          </div>
        </div>
        <div class="form-group">
          <label class="control-label col-sm-2" for="pwd">Direccion:</label>
          <div class="col-sm-10">
            <input type="text" class="form-control" id="Direccion" name="Direccion" placeholder="Direccion" required>
          </div>
        </div>

        <div class="form-group">
          <label class="control-label col-sm-2" for="pwd">Telefono:</label>
          <div class="col-sm-10">
            <input type="text" class="form-control" id="Telefono" name="Telefono" placeholder="Telefono" required>
          </div>
        </div>



        <div class="form-group">
          <label class="control-label col-sm-2" for="pwd">DNI:</label>
          <div class="col-sm-10">
            <input type="text" class="form-control" id="DNI" name="DNI" placeholder="DNI" required>
          </div>
        </div>

        <div class="form-group">
          <label class="control-label col-sm-2" for="pwd">ID Repartidor:</label>
          <div class="col-sm-10">
            <input type="text" class="form-control" id="IDrepartidor" name="IDrepartidor" placeholder="IDrepartidor" required>
          </div>
        </div>




        <div class="form-group">
          <div class="col-sm-offset-2 col-sm-10">
            <button type="submit" class="btn btn-primary">Guardar</button>
          </div>
        </div>
      </form>



    </div>
  </div>


</div>