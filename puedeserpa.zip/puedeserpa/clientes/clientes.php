<script>
	function eliminar(codcliente) {

		var confirma = confirm("Desea eliminar al Productos " + codcliente + "?");
		if (confirma) {
			window.location.href = "clientes/eliminar.php?codcliente=" + codcliente;

		}
		// //href='eliminar.php?id=".$row["id"]."'
	}

	function editar(codcliente) {
		window.location.href = "principal.php?op=formEditar&codcliente=" + codcliente;

	}
</script>

<?php

include_once("Connection.php");
?>
<div class="container">


	<h2>Lista de Clientes</h2>
	<div align="right"> <a href="principal.php?op=ClienteNuevo" class="btn btn-primary"> <span class="glyphicon glyphicon-plus"></span> Nuevo </a></div>

	<br>
	<table id="example" class="table table-striped table-bordered table-hover " style="width:100%">
		<thead>
			<tr>
				<th>Id</th>
				<th>Nombre</th>
				<th>Direccion</th>
				<th>Telefono</th>
				<th>DNI</th>
				<th>ID Repartidor</th>
				<th>Editar</th>
				<th>Eliminar</th>
			</tr>
		</thead>

		<tbody>
			<?php

			$request = Connection::runQuery("SELECT `codcliente`, `nombre`, `dirección`, `tel`, `dni`, `id_repartidor` FROM `cliente_local` ");

			while ($row = mysqli_fetch_assoc($request)) {
				echo "<tr>";
				echo " <td>" . $row["codcliente"] . " </td>";
				echo " <td>" . $row["nombre"] . " </td>";
				echo " <td>" . $row["dirección"] . " </td>";
				echo " <td>" . $row["tel"] . " </td>";
				echo " <td>" . $row["dni"] . " </td>";
				echo " <td>" . $row["id_repartidor"] . " </td>";



				echo " <td width='2%'><a  href='#'  onClick= 'editar(" . $row["codcliente"] . ")'  class='btn btn-info input-sm'><span class='glyphicon glyphicon-pencil'></span></a></td>";
				echo "<td width='2%'><a  class='btn btn-danger input-sm' onClick= 'eliminar(" . $row["codcliente"] . ")' ><span class='glyphicon glyphicon-trash'></span></a></td>";

				echo "</tr>";

				//echo $row["usuario"]." ". $row["clave"]." ".$row["descripcion"]." ". $row["estado"]."<hr>";

			}



			?>



		</tbody>
	</table>
</div>


<?php


/*


$request=Connection::runQuery("SELECT usuarios.id, `usuario`, `clave`, tipo_usuarios.descripcion, `estado` FROM `usuarios`, tipo_usuarios WHERE usuarios.id_tipo=tipo_usuarios.id ");

while ($row = mysqli_fetch_assoc($request)){
	echo $row["usuario"]." ". $row["clave"]." ".$row["descripcion"]." ". $row["estado"]."<hr>";
 
}
*/


?>