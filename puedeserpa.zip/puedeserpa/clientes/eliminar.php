
<?php
include_once("../Connection.php");
//header('Content-Type: application/json; charset=utf-8');


$resu = Connection::runQuery("DELETE FROM `cliente_local` WHERE `codcliente` =" . $_GET["codcliente"]);

header('Location: ../principal.php?op=cliente');
?>
 
 