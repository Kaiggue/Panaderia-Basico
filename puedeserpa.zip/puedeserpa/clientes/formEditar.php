
 <?php

include_once("Connection.php");
?>
<div class="container">
  
  <br>
  <div class="panel-group">
    <div class="panel panel-default">
      <div class="panel-heading">Editar Clientes</div>
      <div class="panel-body">
	  
	  <?php

    $request=Connection::runQuery("SELECT * FROM `cliente_local` WHERE codcliente= ".$_GET["codcliente"]." ");
	
	while ($row = mysqli_fetch_assoc($request)){
	
		$Nombre=$row["nombre"];
		$Direccion=$row["dirección"];
		$TEL=$row["tel"];
    $DNI=$row["dni"];
    $IDRepartidor=$row["id_repartidor"];
		
		
	}
	
	?>
      
      <form class="form-horizontal"  action="clientes/nuevoCliente.php" method="POST">

      <input name="operacion" type="hidden" value="editar" >
			 <input name="codcliente" type="hidden" value="<?php echo $_GET["codcliente"]; ?>" >


  <div class="form-group">
    <label class="control-label col-sm-2" for="Descripcion">Nombre:</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="Nombre" name="Nombre" placeholder="Nombre"  value="<?php echo 	$Nombre ?>" required>
    </div>
  </div>
  <div class="form-group">
    <label class="control-label col-sm-2" for="pwd">Direccion:</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="Direccion" name="Direccion" placeholder="Direccion" value="<?php echo $Direccion ?>"  required>
    </div>
  </div>

  <div class="form-group">
    <label class="control-label col-sm-2" for="pwd">Telefono:</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="TEL" name="TEL" placeholder="TEL" value="<?php echo $TEL ?>" required>
    </div>
  </div>


  
  <div class="form-group">
    <label class="control-label col-sm-2" for="pwd">DNI:</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="DNI" name="DNI" placeholder="DNI"  value="<?php echo  $DNI ?>" required>
    </div>
  </div>

  <div class="form-group">
    <label class="control-label col-sm-2" for="pwd">IDRepartidor:</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="IDRepartidor" name="IDRepartidor" placeholder="IDRepartidor"  value="<?php echo  $IDRepartidor ?>" required>
    </div>
  </div>


 

  
  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
      <button type="submit" class="btn btn-primary" >Enviar</button>
    </div>
  </div>
</form>
      
      </div>
    </div>
   
  </div>
</div>

