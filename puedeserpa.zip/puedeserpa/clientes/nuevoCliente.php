
<?php 
include_once("../Connection.php");
//header('Content-Type: application/json; charset=utf-8');

//echo $_POST["operacion"]."datos";
if($_POST["operacion"]=="editar"){

$resu=Connection::runQuery("UPDATE `cliente_local` SET `nombre`='".$_POST["Nombre"]."',`dirección`='".$_POST["Direccion"]."',`tel`='".$_POST["TEL"]."',`dni`='".$_POST["DNI"]."',`id_repartidor`='".$_POST["IDRepartidor"]."' WHERE `codcliente` ='".$_POST["codcliente"]."'");




//echo "UPDATE `cliente_local` SET `nombre`='".$_POST["Nombre"]."',`dirección`='".$_POST["Direccion"]."',`tel`='".$_POST["TEL"]."',`dni`='".$_POST["DNI"]."',`id_repartidor`='".$_POST["IDRepartidor"]."'";
}
else
$resu=Connection::runQuery("INSERT INTO `cliente_local`(`nombre`, `dirección`, `tel`, `dni`, `id_repartidor`) VALUES ('".$_POST["Nombre"]."','".$_POST["Direccion"]."','".$_POST["Telefono"]."','".$_POST["DNI"]."','".$_POST["IDrepartidor"]."')");

//echo "INSERT INTO `cliente_local`(`nombre`, `dirección`, `tel`, `dni`, `id_repartidor`) VALUES ('".$_POST["Nombre"]."','".$_POST["Direccion"]."','".$_POST["Telefono"]."','".$_POST["DNI"]."','".$_POST["IDrepartidor"]."')"

header('Location: ../principal.php?op=cliente');
 ?>
 