<?php
include_once("../Connection.php");


$operacion = $_REQUEST['operacion'];

switch ($operacion) {
  case 'agregarproducto':
    agregarproductos();
    // code...
    break;
  case 'registrar':
    registrar();

    break;

  default:
    // code...
    break;
}


function agregarproductos()
{

  $id_producto = $_REQUEST['producto_traer'];
  $cantidad = $_REQUEST['cantidad'];

  /*
  $total = cantidad * precio;
*/
  $request = Connection::runQuery("SELECT `precio_compra`,`descripción`,`id_productos`  FROM productos WHERE id_productos= " . $id_producto);


  /*
  $request=Connection::runQuery("SELECT `cantidad` FROM detalle_compra WHERE id_productos= ".$id_producto);

 */
  while ($row = mysqli_fetch_assoc($request)) {

    echo "<br> El ID es: ";
    echo $row["id_productos"];



    echo "<br> El producto es: ";
    echo $row["descripción"];

    echo "<br> El precio del producto es: ";
    echo $row["precio_compra"];

    $precio = $row["precio_compra"];


    echo "<br>";
  }


  $producto = [];
  $producto['id_productos'] = $id_producto;
  $producto['precio'] = $precio;
  $producto['cantidad'] = $cantidad;
  echo "<br>";

  echo "<br>";

  @$_SESSION[productos][] = $producto;
  @print_r($_SESSION[productos]);

  echo count(@$_SESSION[productos]);

  registrar();
}


function registrar()
{


  $fecha = $_POST['fecha'];
  $proveedor = $_POST['id_proveedor'];

  $resu = Connection::runQuery("INSERT INTO `compra`(`id_proveedor`,`fecha`) 
    VALUES ('" . $fecha . "','" . $proveedor . "')");



  for ($i = 0; $i < count(@$_SESSION[productos]); $i++) {
    echo "<br>";
    $id_producto = @$_SESSION[productos][$i]['id_productos'];
    $precio = @$_SESSION[productos][$i]['precio'];
    $cantidad = @$_SESSION[productos][$i]['cantidad'];

    $resu = Connection::runQuery("INSERT INTO `detalle_compra`( `id_productos`,`id_compra`, `precio`, `cantidad`) 
    VALUES ('" . $id_producto . "','" . $precio . "','" . $cantidad . "')");
  }
}
?>