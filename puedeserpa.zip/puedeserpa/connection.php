<?php
class connection
{
 

public static function runQuery($query)
	{
	
	$link = mysqli_connect("localhost","root","","panambi");

		if (!$link) {
			echo "Error: connect a MySQL." . PHP_EOL;
			echo "error: " . mysqli_connect_errno() . PHP_EOL;
		
			exit;
		}
        mysqli_set_charset($link,"utf8");
		$result = mysqli_query($link ,$query);
		 mysqli_close($link);
   return $result;
}

public static function ligin(){

}



}
?>