<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title>Panaderia</title>
    <!-- NORMALIZAR LA PAGINAS ANTES QUE TODO -->
    <link rel="stylesheet" href="css/normalize.css">
    <!-- SIEMPRE LAS LIBRERIAS PRIMERO -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap" rel="stylesheet">

    <!-- CSS  -->
    <link rel="preload" href="estilasos/style.css" as="style">
    <link rel="stylesheet" href="estilasos/style.css">

    <link rel="preload" href="estilasos/style.css" as="style">
    <link rel="stylesheet" href="estilasos/style.css">


</head>

<body>



    <header>

        <div align="center"><img src="img/logo.png"></div>

        <!--     <div class="phone-box"  align="right">

            LLAMANOS PARA HACER TU PEDIDO

            <span class="phone">0800-222-2225</span> -->

        <!--  <h1 class="tittle">Panaderia </h1> -->
    </header>

    <div class="nav-bg">

        <nav class="main-navigation container">
            <a href="index.php">Inicio</a>
            <a href="empresa.php">Empresa</a>
            <a href="productos.php">Productos</a>
            <a href="#">Sucursales</a>
            <a href="loginpantalla.php">Entrar</a>

        </nav>
    </div>

    <section class="hero">
        <div class="contenido-hero">
            <!--   <h2 >Una familia <span> de cosas ricas!</span></h2>
 -->

            <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-map-2" width="40" height="40"
                viewBox="0 0 24 24" stroke-width="1.5" stroke="#ffec00" fill="none" stroke-linecap="round"
                stroke-linejoin="round">
                <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                <line x1="18" y1="6" x2="18" y2="6.01" />
                <path d="M18 13l-3.5 -5a4 4 0 1 1 7 0l-3.5 5" />
                <polyline points="10.5 4.75 9 4 3 7 3 20 9 17 15 20 21 17 21 15" />
                <line x1="9" y1="4" x2="9" y2="17" />
                <line x1="15" y1="15" x2="15" y2="20" />
            </svg>
            <p>Uruguay 3300 - Posadas Misiones - Argentina </p>
            <a class="boton" href="https://api.whatsapp.com/send?phone=543764152078&text=System%20Analist"  target="_blank">Contactar</a>
        </div> <!-- CONTENIDO HERO -->
    </section>

    <main class="container sombra">
        <h2> Historia </h2>
        <h3><i>Confitería Isis nacía en el año 1997 abriendo las puertas de su primera sucursal en la Av. Uruguay 3300
            como un emprendimiento familiar. En sus inicios contaba con un muy reducido grupo de colaboradores y la
            atención personalizada de sus dueños.<br>

            <br>Corría el año 1999, y gracias al apoyo y confianza de su ya amplia clientela, se concreta la apertura de su
            segunda sucursal en la Av. Corrientes 559.<br>

          <br>  Desde entonces Panaderia Isis se ha dedicado a la elaboración artesanal de sus productos, utilizando
            materias primas de máxima calidad tanto nacionales como importadas, brindando un toque único y especial en
            toda su variedad.

            Hoy continúan llevando adelante este sueño, que comenzó hace ya dos décadas padres e hijos, para brindarles
            a sus clientes la mejor calidad y atención.
            Así Confitería Isis forma “ Una familia de cosas ricas”.</i></h3>





    </main>
    <footer class="footer">
        <p>2017 - ISIS CONFITERÍA</p>
        <p>Todos los derechos reservados</p>
        <a href="https://github.com/Kaiggue" target="_blank">Juan Herrera</a>
    </footer>


</body>

</html>