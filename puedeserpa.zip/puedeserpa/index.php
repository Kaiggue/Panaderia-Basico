<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title>Panaderia</title>
    <!-- NORMALIZAR LA PAGINAS ANTES QUE TODO -->
    <link rel="stylesheet" href="css/normalize.css">
    <!-- SIEMPRE LAS LIBRERIAS PRIMERO -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap" rel="stylesheet">

    <!-- CSS  -->
    <link rel="preload" href="estilasos/style.css" as="style">
    <link rel="stylesheet" href="estilasos/style.css">

    <link rel="preload" href="estilasos/style.css" as="style">
    <link rel="stylesheet" href="estilasos/style.css">


</head>

<body>



    <header>

        <div align="center"><img src="img/logo.png"></div>

        <!--     <div class="phone-box"  align="right">

            LLAMANOS PARA HACER TU PEDIDO

            <span class="phone">0800-222-2225</span> -->

        <!--  <h1 class="tittle">Panaderia </h1> -->
    </header>

    <div class="nav-bg">

        <nav class="main-navigation container">
            <a href="index.php">Inicio</a>
            <a href="empresa.php">Empresa</a>
            <a href="productos.php">Productos</a>
            <a href="#">Sucursales</a>
            <a href="loginpantalla.php">Entrar</a>

        </nav>
    </div>

    <section class="hero">
        <div class="contenido-hero">
            <!--   <h2 >Una familia <span> de cosas ricas!</span></h2>
 -->

            <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-map-2" width="40" height="40" viewBox="0 0 24 24" stroke-width="1.5" stroke="#ffec00" fill="none" stroke-linecap="round" stroke-linejoin="round">
                <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                <line x1="18" y1="6" x2="18" y2="6.01" />
                <path d="M18 13l-3.5 -5a4 4 0 1 1 7 0l-3.5 5" />
                <polyline points="10.5 4.75 9 4 3 7 3 20 9 17 15 20 21 17 21 15" />
                <line x1="9" y1="4" x2="9" y2="17" />
                <line x1="15" y1="15" x2="15" y2="20" />
            </svg>
            <p>Uruguay 3300 - Posadas Misiones - Argentina </p>
            <a class="boton" href="https://api.whatsapp.com/send?phone=543764152078&text=System%20Analist" target="_blank">Contactar</a>
        </div> <!-- CONTENIDO HERO -->
    </section>

    <main class="container sombra">
        <h2> Una familia de cosas ricas! </h2>
        <h3><i>Nuestra visión sobre la pastelería crece desde la apertura de nuestro primer local en Montes de Oca, a
                partir de ese momento nuestra misión como empresa fue satisfacer las necesidades de todos nuestros clientes
                y ofrecer productos de primera calidad. Los invitamos a probar nuestra variedad de dulces y salados en sus
                fiestas, reuniones y eventos.</i></h3>


        </div>


        <section class="servicio">
            <h5><svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-mail" width="88" height="88" viewBox="0 0 24 24" stroke-width="1.5" stroke="#ff2825" fill="none" stroke-linecap="round" stroke-linejoin="round">
                    <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                    <rect x="3" y="5" width="18" height="14" rx="2" />
                    <polyline points="3 7 12 13 21 7" />
                </svg> 
           
            <h3>CONTÁCTENOS Y PRESUPUESTE SU EVENTO</h3>
            <h5> </h5>
            <form class="formulario">

                <fieldset>

                    <legend>Ofrecemos Servicios Gastronómicos para todo tipo de eventos como; casamientos, cocktails, desfiles, cumpleaños de 15, convenciones, exposiciones, eventos sociales, culturales y empresariales.</legend>

                    <div class="contenedor-campos">
                        <div class="campo">
                            <label for="">Nombre</label>
                            <input class="input-text" type="text" placeholder="Tu Nombre">
                        </div>

                        <div class="campo"> <label for="">Telefono</label>
                            <input class="input-text" type="tel" placeholder="Telefono">
                        </div>

                        <div class="campo"> <label for="">Correo</label>
                            <input class="input-text" type="mail" placeholder="Correo">
                        </div>

                        <div class="campo">
                            <label for="">Mensaje</label>
                            <textarea class="input-text" name="" id="" cols="30" rows="10"></textarea>
                        </div>

                    </div> <!-- DIV GENERAL -->


                    <div class="alinear-derecha flex">
                        <input class="boton w-sm-100" type="submit" value="Enviar" name="" id="">
                    </div>



                </fieldset>

            </form>

            <p>-</p>
        </section>


    </main>


    <footer class="footer">
        
        <p>2017 - ISIS CONFITERÍA</p>

        <p>Todos los derechos reservados</p>
        <a href="https://github.com/Kaiggue" target="_blank">Juan Herrera</a>
    </footer>


</body>

</html>