
 <?php

include_once("connection.php");
?>
<div class="container">
  
  <br>
  <div class="panel-group">
    <div class="panel panel-default">
      <div class="panel-heading">Editar compra</div>
      <div class="panel-body">
	  
	  <?php

    $request=Connection::runQuery("SELECT * FROM `compras` WHERE id_compra= ".$_GET["id_compra"]." ");
	
	while ($row = mysqli_fetch_assoc($request)){
	

		$total_compra=$row["total_compra"];
    $fecha=$row["fecha"];

		
		/* if($tipo=="Administrador")
		$admin= "selected='selected'"; 
		if($tipo=="Operario")
		$oper= "selected='selected'"; 
		 */
		
	/* 	if($estado=="1")
		$activo="checked='checked'"; */
	}
	
	?>
      
      <form class="form-horizontal"  action="compras/agregar_compra.php" method="POST">

      <input name="operacion" type="hidden" value="editar" >
			 <input name="id_compra" type="hidden" value="<?php echo $_GET["id_compra"]; ?>" >


  <div class="form-group">
    <label class="control-label col-sm-2" for="Descripcion">Total de compra:</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="descripcion" name="descripcion" placeholder="Descripcion"  value="<?php echo 	$total_compra ?>" required>
    </div>
  </div>
  <div class="form-group">
    <label class="control-label col-sm-2" for="pwd">Fecha:</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="stock" name="stock" placeholder="Stock" value="<?php echo $fecha ?>"  required>
    </div>
  </div>



  
  
  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
      <button type="submit" class="btn btn-primary" >Enviar</button>
    </div>
  </div>
</form>
      
      </div>
    </div>
   
  </div>
</div>

