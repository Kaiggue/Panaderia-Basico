<?php
include_once("../Connection.php");
//header('Content-Type: application/json; charset=utf-8');

$resu2 = Connection::runQuery("DELETE FROM `detalle_compra` WHERE `id_compra`    =" . $_GET["id_compra"]);

$resu = Connection::runQuery("DELETE FROM `compras` WHERE `id_compra`  =" . $_GET["id_compra"]);

header('Location: ../principal.php?op=listacompras');
?>
 
 