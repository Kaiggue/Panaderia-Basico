<script>
	function eliminar(id_compra) {

		var confirma = confirm("Desea eliminar a la compra? " + id_compra + "?");
		if (confirma) {
			window.location.href = "listacompra/eliminar.php?id_compra=" + id_compra;

		}
		// //href='eliminar.php?id=".$row["id"]."'
	}

	function editar(id_compra) {
		window.location.href = "principal.php?op=editarcompra&id_compra=" + id_compra;

	}
</script>

<?php

include_once("Connection.php");
?>
<div class="container">


	<h2>Lista de Compras</h2>

	<br>
	<table id="example" class="table table-striped table-bordered table-hover " style="width:100%">
		<thead>
			<tr>
				<th>ID Compra</th>
				<th>ID Proveedor</th>
				<th>Total de Compra</th>
				<th>Fecha</th>
				<th>Eliminar</th>
			</tr>
		</thead>

		<tbody>
			<?php

			$request = Connection::runQuery("SELECT `id_compra`, `id_proveedor`, `total_compra`, `fecha` FROM `compras` ");

			while ($row = mysqli_fetch_assoc($request)) {
				echo "<tr>";
				echo " <td>" . $row["id_compra"] . " </td>";
				echo " <td>" . $row["id_proveedor"] . " </td>";
				echo " <td>" . $row["total_compra"] . " </td>";
				echo " <td>" . $row["fecha"] . " </td>";


/* 				echo " <td width='2%'><a  href='#'  onClick= 'editar(" . $row["id_compra"] . ")'  class='btn btn-info input-sm'><span class='glyphicon glyphicon-pencil'></span></a></td>";
 */				echo "<td width='2%'><a  class='btn btn-danger input-sm' onClick= 'eliminar(" . $row["id_compra"] . ")' ><span class='glyphicon glyphicon-trash'></span></a></td>";

				echo "</tr>";

				//echo $row["usuario"]." ". $row["clave"]." ".$row["descripcion"]." ". $row["estado"]."<hr>";

			}



			?>



		</tbody>
	</table>
</div>


<?php


/*


$request=Connection::runQuery("SELECT usuarios.id, `usuario`, `clave`, tipo_usuarios.descripcion, `estado` FROM `usuarios`, tipo_usuarios WHERE usuarios.id_tipo=tipo_usuarios.id ");

while ($row = mysqli_fetch_assoc($request)){
	echo $row["usuario"]." ". $row["clave"]." ".$row["descripcion"]." ". $row["estado"]."<hr>";
 
}
*/


?>