<?php
include_once("../Connection.php");
//header('Content-Type: application/json; charset=utf-8');


$resu2 = Connection::runQuery("DELETE FROM `detalle_ventas` WHERE `cod_ventas` =" . $_GET["cod_ventas"]);

$resu = Connection::runQuery("DELETE FROM `ventas` WHERE `cod_ventas` =" . $_GET["cod_ventas"]);

header('Location: ../principal.php?op=listaventa');
?>
 
 