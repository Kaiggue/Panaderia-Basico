<script>
	function eliminar(cod_ventas) {

		var confirma = confirm("Desea eliminar a la compra? " + cod_ventas + "?");
		if (confirma) {
			window.location.href = "listaventa/eliminar.php?cod_ventas=" + cod_ventas;

		}
		// //href='eliminar.php?id=".$row["id"]."'
	}

	function editar(cod_ventas) {
		window.location.href = "principal.php?op=editarventa&cod_ventas=" + cod_ventas;

	}
</script>

<?php

include_once("Connection.php");
?>
<div class="container">


	<h2>Lista de Ventas</h2>

	<br>
	<table id="example" class="table table-striped table-bordered table-hover " style="width:100%">
		<thead>
			<tr>
				<th>ID Venta</th>
				<th>ID Cliente</th>
				<th>Total</th>
				<th>Fecha</th>

				<th>Eliminar</th>
			</tr>
		</thead>

		<tbody>
			<?php

			$request = Connection::runQuery("SELECT `cod_ventas`, `codcliente`, `total_ventas`, `fecha` FROM `ventas` ");

			while ($row = mysqli_fetch_assoc($request)) {
				echo "<tr>";
				echo " <td>" . $row["cod_ventas"] . " </td>";
				echo " <td>" . $row["codcliente"] . " </td>";
				echo " <td>" . $row["total_ventas"] . " </td>";
				echo " <td>" . $row["fecha"] . " </td>";


/* 				echo " <td width='2%'><a  href='#'  onClick= 'editar(" . $row["cod_ventas"] . ")'  class='btn btn-info input-sm'><span class='glyphicon glyphicon-pencil'></span></a></td>";
 */				echo "<td width='2%'><a  class='btn btn-danger input-sm' onClick= 'eliminar(" . $row["cod_ventas"] . ")' ><span class='glyphicon glyphicon-trash'></span></a></td>";

				echo "</tr>";

				//echo $row["usuario"]." ". $row["clave"]." ".$row["descripcion"]." ". $row["estado"]."<hr>";

			}



			?>



		</tbody>
	</table>
</div>


<?php


/*


$request=Connection::runQuery("SELECT usuarios.id, `usuario`, `clave`, tipo_usuarios.descripcion, `estado` FROM `usuarios`, tipo_usuarios WHERE usuarios.id_tipo=tipo_usuarios.id ");

while ($row = mysqli_fetch_assoc($request)){
	echo $row["usuario"]." ". $row["clave"]." ".$row["descripcion"]." ". $row["estado"]."<hr>";
 
}
*/


?>