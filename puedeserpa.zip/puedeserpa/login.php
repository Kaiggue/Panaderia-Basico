<?php


include_once 'connection.php';
session_start();


$usuario = $_POST["usuario"];
$clave = $_POST["clave"];


$request=Connection::runQuery("SELECT * FROM `usuarios` WHERE `usuario` like '$usuario'  and `clave` like '$clave' ");

$row = mysqli_fetch_assoc($request);

if(strlen($row['usuario']) > 0){


    $_SESSION ["login"] = "ok";
    $_SESSION ["nombreUsuario"]=$row["usuario"];
    $_SESSION ["tipoUsuario"]=$row["id_tipo"];

header ("location: principal.php?op=inicio");
}


else {

    //echo "SELECT * FROM `usuarios` WHERE `usuario` like '$usuario'  and `clave` like '$clave' "  ;
   header ("location: index.php?login=error");

   // echo "usuario/clave INCORRECTA";
}





?>
