<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  


<head>


	<link rel="stylesheet" type="text/css" href="estilo/estilos.css">


	
</head>


<body class="color">
	
<center>	
	<br>
	<br>
	
	<br>
	<br>

<div class="Container">

<form action ="login.php" method="POST">

    <table border="0" width="50%" >
		<br>
      	<tr>
     	 <td><p style="font-weight: 600;">Usuario&nbsp;</p></td>
    	</tr>
    	<tr>
    	  <td><input type="text" name="usuario" id="usuario" size="" class="form-control"> &nbsp;</td>
    	</tr>
    	<tr>
    	  <td><p style="font-weight: 600;">Clave</p></td>
    	</tr>
    	<tr>
    	  <td><input type="password" name="clave" size="" id="clave" class="form-control">&nbsp;</td>
    	</tr>
		<tr>
			<td> </td>
		  </tr>
		  <tr>
			<td> </td>
		  </tr>
   		 <tr>
     	 <td align="center"><input type="submit"  value="Login" class="btn btn-info">&nbsp;</td>
		</tr>
		<tr>
     	
		
	</table>

	
	
	
	
	<br>
	<br>
	<br>
	<div class ="alerta" >
		<td>  
			
		
		<?php
    
	
	
	if(isset($_GET["login"])) 
	
	echo  "EL USUARIO O LA CLAVE ES INCORRECTA !!!!!! "

		 ?>    
 
</td>
		</tr>

	</div>

	</form>
</div>




</body>
    
</html>