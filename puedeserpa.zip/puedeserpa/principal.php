<!DOCTYPE html>
<html lang="en">

<head>
  <title>PANAMBI</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- NORMALIZAR LA PAGINAS ANTES QUE TODO -->
  <link rel="stylesheet" href="css/normalize.css">

  <link rel="stylesheet" href="css/estilos.css"> <!-- CARGO CSS -->
  <link rel="preload" href="css/estilos.css" as="style"> <!-- CARGA RAPIDA PRELOAD -->

  <!-- ACTUALIZAR ESTILOS CSS - PHP - EN TIEMPO REAL -->
  <link rel="stylesheet" href="css/estilos.css?v=<?php echo time(); ?>" />

  <!-- BOOSTRAP Y AJAX -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

  <!-- DATA TABLES -->
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.css">
  <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.js"></script>
  <script type="text/javascript" charset="utf8" src="popper/main.js"></script>
  <!-- DATA TABLES -->
  <link rel="stylesheet" href="css/datatables.min.css">
  <link rel="stylesheet" href="css/datatables/css/dataTables.bootstrap4.min.css">



  <!-- FUENTES  -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100&display=swap" rel="stylesheet">

  <script type="text/javascript" href=""> </script>



  <link rel="stylesheet" href="css/datatables/css/dataTables.bootstrap4.min.css">


</head>

<body>




  <?php

  session_start();

  include_once("Connection.php");

  if ($_SESSION["login"] == "ok") {




  ?>


    <nav class="navbar navbar-default panaderia">
      <a class="navbar-brand" href="principal.php?op=inicio">
        <b class="panaderia">PANADERIA PANAMBI<b> </a>



      <ul class="nav navbar-nav">
        <!-- Ordena mi navbar -->





        <li class="subconjunto">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#">Productos <span class="caret"></span></a>
          <ul class="dropdown-menu ">
            <li><a href="principal.php?op=producto">Nuevo Productos</a></li>
            <li><a href="principal.php?op=compras">Compras</a></li>
            <li><a href="principal.php?op=ventas">Ventas</a></li>
          </ul>
        </li>

        <li class="subconjunto">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#">Compras/Ventas<span class="caret"></span></a>
          <ul class="dropdown-menu ">
            <li>
              <a href="principal.php?op=listacompras">Lista de compras</a>

              <a href="principal.php?op=listaventa">Lista de ventas</a>
              <a href="principal.php?op=grafico_compras">Grafico Productos</a>
            </li>


          </ul>
        </li>



        <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Proveedor <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="principal.php?op=proveedor">Nuevo Proveedor</a></li>

          </ul>
        </li>

        <?php
        if ($_SESSION["tipoUsuario"] == "1") {

          echo "<li><a href='principal.php?op=usuarios'>Usuario</a></li>";
        }

        ?>




        <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Clientes <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="principal.php?op=cliente">Nuevo Clientes</a></li>
          </ul>

        <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Repartidores <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="principal.php?op=repartidor">Nuevo Repartidor</a></li>
          </ul>

      </ul>


      <ul class="nav navbar-nav navbar-right">
        <li><a href="principal.php?op=usuarios"><span class="glyphicon glyphicon-user"></span> <?php echo $_SESSION["nombreUsuario"]; ?> </a></li>
        <li><a href="salir.php">
            <span class="glyphicon glyphicon-log-in">



            </span> Salir</a></li>
      </ul>
      </div>
    </nav>

    <div class="container">

      <?php

      if ($_GET["op"] == "inicio") {

        include "inicio.php";
      }

      if ($_GET["op"] == "usuarios") {

        include "usuario/usuarios.php";
      }
      if ($_GET["op"] == "editarUsuario") {

        include "usuario/formEditar.php";
      }
      if ($_GET["op"] == "nuevo") {

        include "usuario/Form.php";
      }


      if ($_GET["op"] == "listacompras") {

        include "listacompra/listacompras.php";
      }


      if ($_GET["op"] == "editarcompra") {

        include "listacompra/editarcompra.php";
      }


      if ($_GET["op"] == "eliminarcompra") {

        include "listacompra/eliminar.php";
      }


      if ($_GET["op"] == "grafico_compras") {

        include "chart_basico/chart/index.php";
      }

      ////////////////////        VENTAS      ////////////////////


      if ($_GET["op"] == "listaventa") {

        include "listaventa/listaventas.php";
      }

      if ($_GET["op"] == "editarventa") {

        include "listacompra/editarventa.php";
      }

      if ($_GET["op"] == "eliminarventa") {

        include "listaventa/eliminar.php";
      }
      //////////////////////////////////////////////////////////////



      if ($_GET["op"] == "producto") {

        include "productos/productos.php";
      }

      if ($_GET["op"] == "editarProductos") {

        include "productos/formEditar.php";
      }

      if ($_GET["op"] == "Nuevo2") {

        include "productos/Form.php";
      }




      if ($_GET["op"] == "compras") {
        include "compras/compras.php";
      }


      if ($_GET["op"] == "ventas") {
        include "ventas/ventas.php";
      }




      if ($_GET["op"] == "proveedor") {

        include "proveedor/proveedor.php";
      }

      if ($_GET["op"] == "proveedorform") {

        include "proveedor/Form.php";
      }

      if ($_GET["op"] == "editarProveedor") {

        include "proveedor/formEditar.php";
      }



      if ($_GET["op"] == "cliente") {

        include "clientes/clientes.php";
      }

      if ($_GET["op"] == "ClienteNuevo") {

        include "clientes/Form.php";
      }

      if ($_GET["op"] == "formEditar") {

        include "clientes/formEditar.php";
      }



      if ($_GET["op"] == "repartidor") {

        include "repartidores/repartidor.php";
      }

      if ($_GET["op"] == "Form") {

        include "repartidores/Form.php";
      }

      if ($_GET["op"] == "editarRepartidor") {

        include "repartidores/formEditar.php";
      }


      ?>


    </div>
  <?php
  } else {

    header("location: index.php?login=error");
  }

  ?>
 <p>-</p>
<footer class="footer">
        <p>2017 - ISIS CONFITERÍA </p>

        <p>Todos los derechos reservados</p>
    </footer>

</body>


</html>