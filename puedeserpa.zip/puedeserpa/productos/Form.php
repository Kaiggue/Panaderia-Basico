

<div class="container">
<br>
<br> 
  <div class="navbar navbar-default">
      <div class="panel-heading">Nuevo Productos</div>
      <div class="panel-body">
      
      <form class="form-horizontal"  action="productos/nuevoProductos.php" method="POST">
  <div class="form-group">
    <label class="control-label col-sm-2" for="Descripcion">Descripcion:</label>
    <div class="col-sm-10">
      <input type="descripcion" class="form-control" id="descripcion" name="descripcion" placeholder="Descripcion" required>
    </div>
  </div>
  <div class="form-group">
    <label class="control-label col-sm-2" for="pwd">Stock:</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="stock" name="stock" placeholder="Stock" required>
    </div>
  </div>

  <div class="form-group">
    <label class="control-label col-sm-2" for="pwd">Precio de Compra:</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="PreciodeCompra" name="PreciodeCompra" placeholder="Precio de Compra" required>
    </div>
  </div>


  
  <div class="form-group">
    <label class="control-label col-sm-2" for="pwd">Precio de Ventas:</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="PreciondeVentas" name="PreciodeVentas" placeholder="Precio de Ventas" required>
    </div>
  </div>



  
  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
      <button type="submit" class="btn btn-primary" >Guardar</button>
    </div>
  </div>
</form>
      
      
      
      </div>
    </div>

   
</div>

