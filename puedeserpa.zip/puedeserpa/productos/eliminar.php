
<?php 
include_once("../Connection.php");
//header('Content-Type: application/json; charset=utf-8');


$resu=Connection::runQuery("DELETE FROM `productos` WHERE `id_productos` =".$_GET["id_productos"]);

header('Location: ../principal.php?op=producto');
 ?>
 
 