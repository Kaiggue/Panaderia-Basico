
 <?php

include_once("connection.php");
?>
<div class="container">
  
  <br>
  <div class="panel-group">
    <div class="panel panel-default">
      <div class="panel-heading">Editar Productos</div>
      <div class="panel-body">
	  
	  <?php

    $request=Connection::runQuery("SELECT * FROM `productos` WHERE id_productos= ".$_GET["id_productos"]." ");
	
	while ($row = mysqli_fetch_assoc($request)){
	
		$descripcion=$row["descripción"];
		$stock=$row["stock"];
		$PreciodeCompra=$row["precio_compra"];
    $PreciodeVentas=$row["precio_ventas"];
    $estado=$row["estado"];
		
		/* if($tipo=="Administrador")
		$admin= "selected='selected'"; 
		if($tipo=="Operario")
		$oper= "selected='selected'"; 
		 */
		
		if($estado=="1")
		$activo="checked='checked'";
	}
	
	?>
      
      <form class="form-horizontal"  action="productos/nuevoProductos.php" method="POST">

      <input name="operacion" type="hidden" value="editar" >
			 <input name="id_productos" type="hidden" value="<?php echo $_GET["id_productos"]; ?>" >


  <div class="form-group">
    <label class="control-label col-sm-2" for="Descripcion">Descripcion:</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="descripcion" name="descripcion" placeholder="Descripcion"  value="<?php echo 	$descripcion ?>" required>
    </div>
  </div>
  <div class="form-group">
    <label class="control-label col-sm-2" for="pwd">Stock:</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="stock" name="stock" placeholder="Stock" value="<?php echo $stock ?>"  required>
    </div>
  </div>

  <div class="form-group">
    <label class="control-label col-sm-2" for="pwd">Precio de Compra:</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="PreciodeCompra" name="PreciodeCompra" placeholder="Precio de Compra" value="<?php echo $PreciodeCompra ?>" required>
    </div>
  </div>


  
  <div class="form-group">
    <label class="control-label col-sm-2" for="pwd">Precio de Ventas:</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="PreciondeVentas" name="PreciodeVentas" placeholder="Precio de Ventas"  value="<?php echo  $PreciodeVentas ?>" required>
    </div>
  </div>


  
  
  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
      <button type="submit" class="btn btn-primary" >Enviar</button>
    </div>
  </div>
</form>
      
      </div>
    </div>
   
  </div>
</div>

