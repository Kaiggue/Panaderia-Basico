
<?php 
include_once("../connection.php");
//header('Content-Type: application/json; charset=utf-8');

//echo $_POST["operacion"]."datos";
if($_POST["operacion"]=="editar"){

    $resu=Connection::runQuery("UPDATE `productos` SET `descripción`='".$_POST["descripcion"]."',`stock`=".$_POST["stock"].",`precio_compra`=".$_POST["PreciodeCompra"].",`precio_ventas`=".$_POST["PreciodeVentas"].",`estado`=1 where id_productos =".$_POST["id_productos"]);
    //echo "UPDATE `productos` SET `descripción`='".$_POST["descripcion"]."',`stock`=".$_POST["stock"].",`precio_compra`=".$_POST["PreciodeCompra"].",`precio_ventas`=".$_POST["PreciodeVentas"].",`estado`=1 where id_productos =".$_POST["id_productos"];
}
else
$resu=Connection::runQuery("INSERT INTO `productos`(`descripción`, `stock`, `precio_compra`, `precio_ventas`, `estado`) VALUES ('".$_POST["descripcion"]."',".$_POST["stock"].",'".$_POST["PreciodeCompra"]."','".$_POST["PreciodeVentas"]."',1)");



header('Location: ../principal.php?op=producto');
 ?>
 