
<script>
 function eliminar(id_productos){

	 var confirma=confirm ("Desea eliminar al Productos "+ id_productos +"?") ;
	 if(confirma){
		window.location.href = "productos/eliminar.php?id_productos="+id_productos;

	 }
	// //href='eliminar.php?id=".$row["id"]."'
 }

 function editar(id_productos){
   window.location.href = "principal.php?op=editarProductos&id_productos="+id_productos;

}


</script>

<?php

include_once("connection.php");
?>
<div class="container">


<h2>Lista de Productos</h2>
<div align="right"> <a  href="principal.php?op=Nuevo2" class="btn btn-primary"> <span class="glyphicon glyphicon-plus"></span> Nuevo </a></div>

<br>
<table id="example" class="table table-striped table-bordered table-hover " style="width:100%">
    <thead>
      <tr>
        <th>Id</th>
        <th>descripcion</th>
        <th>stock</th>
		<th>precio de compra</th>
		<th>precio de venta</th>
		<th>Editar</th>
		<th>Eliminar</th>
      </tr>
    </thead>
	
    <tbody>
	<?php

   $request=Connection::runQuery("SELECT `id_productos`, `descripción`, `stock`, `precio_compra`, `precio_ventas` FROM `productos` ");
	
	while ($row = mysqli_fetch_assoc($request)){
	      echo "<tr>";
	      echo " <td>". $row["id_productos"]." </td>";
		  echo " <td>". $row["descripción"]." </td>";
		  echo " <td>". $row["stock"]." </td>";
		  echo " <td>". $row["precio_compra"]." </td>";
		  echo " <td>". $row["precio_ventas"]." </td>";
		  
		  
		   
		  echo " <td width='2%'><a  href='#'  onClick= 'editar(". $row["id_productos"].")'  class='btn btn-info input-sm'><span class='glyphicon glyphicon-pencil'></span></a></td>";
		  echo "<td width='2%'><a  class='btn btn-danger input-sm' onClick= 'eliminar(". $row["id_productos"].")' ><span class='glyphicon glyphicon-trash'></span></a></td>";
		  
		  echo "</tr>";
		  
		//echo $row["usuario"]." ". $row["clave"]." ".$row["descripcion"]." ". $row["estado"]."<hr>";
	 
	}


	  
?>
	


    </tbody>
  </table>
</div>


<?php


/*


$request=Connection::runQuery("SELECT usuarios.id, `usuario`, `clave`, tipo_usuarios.descripcion, `estado` FROM `usuarios`, tipo_usuarios WHERE usuarios.id_tipo=tipo_usuarios.id ");

while ($row = mysqli_fetch_assoc($request)){
	echo $row["usuario"]." ". $row["clave"]." ".$row["descripcion"]." ". $row["estado"]."<hr>";
 
}
*/

	  
?>