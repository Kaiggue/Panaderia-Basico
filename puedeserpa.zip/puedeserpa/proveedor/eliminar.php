

<?php 
include_once("../Connection.php");
//header('Content-Type: application/json; charset=utf-8');


$resu=Connection::runQuery("DELETE FROM `proveedor` WHERE `id_proveedor` =".$_GET["id_proveedor"]);

header('Location: ../principal.php?op=proveedor');


 ?>
 
 