<?php

include_once("Connection.php");
?>
<div class="container">

  <br>
  <div class="panel-group">
    <div class="panel panel-default">
      <div class="panel-heading">Editar Usuario</div>
      <div class="panel-body">

        <?php

        $request = Connection::runQuery("SELECT * FROM `proveedor` WHERE id_proveedor= " . $_GET["id_proveedor"] . " ");

        while ($row = mysqli_fetch_assoc($request)) {

          $nombre = $row["nombre"];
          $direccion = $row["direccion"];
          $cuit = $row["cuit"];
          $telefono = $row["telefono"];
          $tipoproveedor = $row["tipo_proveedor"];
        }

        ?>

        <form class="form-horizontal" action="proveedor/nuevoProveedor.php" method="post">

          <input name="operacion" type="hidden" value="editar">
          <input name="id_proveedor" type="hidden" value="<?php echo $_GET["id_proveedor"]; ?>">

          <div class="form-group">
            <label class="control-label col-sm-2" for="usuario">Nuevo Proveedor:</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" id="nombre" name="nombre" placeholder="Nombre" value="<?php echo $nombre; ?>" required>
            </div>
          </div>
          <div class="form-group">
            <label class="control-label col-sm-2" for="pwd">Direccion:</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" id="direccion" name="direccion" placeholder="Direccion" value=" <?php echo $direccion; ?>" required>
            </div>
          </div>

          <div class="form-group">
            <label class="control-label col-sm-2" for="pwd">Cuit:</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" id="cuit" name="cuit" placeholder="Cuit" value=" <?php echo $cuit; ?>" required>
            </div>
          </div>

          <div class="form-group">
            <label class="control-label col-sm-2" for="pwd">Telefono:</label>
            <div class="col-sm-10">
              <input type="Telefono" class="form-control" id="telefono" name="telefono" placeholder="Telefono" value=" <?php echo $telefono; ?>" required>
            </div>
          </div>

          <div class="form-group">
            <label class="control-label col-sm-2" for="pwd">Tipo Proveedor:</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" id="tipo_proveedor" name="tipo_proveedor" placeholder="Tipo Proveedor" value=" <?php echo $tipoproveedor; ?>" required>
            </div>
          </div>



          <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
              <button type="submit" class="btn btn-primary">Guardar</button>
            </div>
          </div>
        </form>

      </div>
    </div>

  </div>
</div>