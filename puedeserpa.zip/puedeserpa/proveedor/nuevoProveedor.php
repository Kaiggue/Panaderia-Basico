
<?php
include_once("../Connection.php");
//header('Content-Type: application/json; charset=utf-8');

if ($_POST["operacion"] == "editar") {

    $resu = Connection::runQuery("UPDATE `proveedor` SET `nombre`='" . $_POST["nombre"] . "',`direccion`='" . $_POST["direccion"] . "',`cuit`='" . $_POST["cuit"] . "',`telefono`='" . $_POST["telefono"] . "', `tipo_proveedor`='" . $_POST["tipo_proveedor"] . "' WHERE `id_proveedor` ='" . $_POST["id_proveedor"] . "'");



    //echo "UPDATE `proveedor` SET `nombre`='".$_POST["Nombre"]."',`direccion`='".$_POST["Direccion"]."',`cuit`='".$_POST["Cuit"]."',`telefono`='".$_POST["Telefono"]."',`tipo_proveedor`='".$_POST["TipoProveedor"]."')";





} else
    $resu = Connection::runQuery("INSERT INTO `proveedor`( `nombre`, `direccion`, `cuit` , `telefono`, `tipo_proveedor`) VALUES ('" . $_POST["Nombre"] . "','" . $_POST["Direccion"] . "','" . $_POST["Cuit"] . "','" . $_POST["Telefono"] . "','" . $_POST["TipoProveedor"] . "')");


//echo "INSERT INTO `proveedor`( `nombre`, `direccion`, `cuit` , `telefono`, `tipo_proveedor`) VALUES ('$Nombre','".$_POST["Direccion"]."','".$_POST["Cuit"]."','".$_POST["Telefono"]."','".$_POST["TipoProveedor"]."')";


header('Location: ../principal.php?op=proveedor');
?>
 
 