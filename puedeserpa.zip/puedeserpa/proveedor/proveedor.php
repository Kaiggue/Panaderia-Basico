
<script>
 function eliminar(id_proveedor){

	 var confirma=confirm ("Desea eliminar al usuario "+ id_proveedor +"?") ;
	 if(confirma){
		window.location.href = "proveedor/eliminar.php?id_proveedor="+id_proveedor;

	 }
	// //href='eliminar.php?id=".$row["id"]."'
 }
 function editar(id_proveedor){
   window.location.href = "principal.php?op=editarProveedor&id_proveedor="+id_proveedor;

}
// //href='eliminar.php?id=".$row["id"]."'







</script>

<?php

include_once("Connection.php");
?>

<div class="container">
  <h2>Lista de Proveedores</h2>
<div align="right"> <a  href="principal.php?op=proveedorform" class="btn btn-primary"> <span class="glyphicon glyphicon-plus"></span> Nuevo </a></div>
<br/>
<table id="example" class="table table-striped table-bordered table-hover " style="width:100%">
    <thead>
      <tr>
        <th>Id</th>
        <th>Nombre</th>
        <th>Direccion</th>
		<th>CUIT</th>
		<th>Telefono</th>
		<th>Tipo Proveedor</th>
		<th>Editar</th>
		<th>Eliminar</th>
      </tr>
    </thead>
	
    <tbody>
	<?php

   $request=Connection::runQuery("SELECT `id_proveedor`, `nombre`, `direccion`, `cuit`, `telefono`, `tipo_proveedor` FROM `proveedor`");
	
	while ($row = mysqli_fetch_assoc($request)){
	      echo "<tr>";
	      echo " <td>". $row["id_proveedor"]." </td>";
		  echo " <td>". $row["nombre"]." </td>";
		  echo " <td>". $row["direccion"]." </td>";
		  echo " <td>". $row["cuit"]." </td>";
		  echo " <td>". $row["telefono"]." </td>";
		  echo " <td>". $row["tipo_proveedor"]." </td>";
		  
		
		  echo " <td width='2%'><a  href='#'  onClick= 'editar(". $row["id_proveedor"].")'  class='btn btn-info input-sm'><span class='glyphicon glyphicon-pencil'></span></a></td>";
		  echo "<td width='2%'><a  class='btn btn-danger input-sm' onClick= 'eliminar(". $row["id_proveedor"].")' ><span class='glyphicon glyphicon-trash'></span></a></td>";
		  
		  echo "</tr>";
		  
		//echo $row["usuario"]." ". $row["clave"]." ".$row["descripcion"]." ". $row["estado"]."<hr>";
	 
	}
		  
	
	  
?>
	


    </tbody>
  </table>
</div>


<?php


/*


$request=Connection::runQuery("SELECT usuarios.id, `usuario`, `clave`, tipo_usuarios.descripcion, `estado` FROM `usuarios`, tipo_usuarios WHERE usuarios.id_tipo=tipo_usuarios.id ");

while ($row = mysqli_fetch_assoc($request)){
	echo $row["usuario"]." ". $row["clave"]." ".$row["descripcion"]." ". $row["estado"]."<hr>";
 
}
*/

	  
?>



