

<?php 
include_once("../Connection.php");
//header('Content-Type: application/json; charset=utf-8');


$resu=Connection::runQuery("DELETE FROM `repartidor` WHERE `id_repartidor` =".$_GET["id_repartidor"]);

header('Location: ../principal.php?op=repartidor');


 ?>
 
 