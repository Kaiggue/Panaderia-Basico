
 <?php

include_once("Connection.php");
?>
<div class="container">
  
  <br>
  <div class="panel-group">
    <div class="panel panel-default">
      <div class="panel-heading">Editar Repartidor</div>
      <div class="panel-body">
	  
	  <?php

    $request=Connection::runQuery("SELECT * FROM `repartidor` WHERE id_repartidor= ".$_GET["id_repartidor"]." ");
	
	while ($row = mysqli_fetch_assoc($request)){
	
		$nombre=$row["nombre"];
		$telefono=$row["telefono"];
		$dirección=$row["dirección"];
    $fechanacimiento=$row["fecha_nacimiento"];
    
		
	
	}
	
	?>
      
      <form class="form-horizontal" action="repartidores/nuevoRepartidor.php" method="post">
	  
	         <input name="operacion" type="hidden" value="editar" >
			 <input name="id_repartidor" type="hidden" value="<?php echo $_GET["id_repartidor"]; ?>" >
			 
            <div class="form-group">
                <label class="control-label col-sm-2" for="usuario">Nombre :</label>
                <div class="col-sm-10">
                <input type="text" class="form-control" id="nombre"  name="nombre" placeholder="Nombre"  value="<?php echo $nombre; ?>" required>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-sm-2" for="pwd">telefono:</label>
                <div class="col-sm-10">
                <input type="text" class="form-control" id="telefono" name="telefono" placeholder="telefono" value=" <?php echo $telefono; ?>" required>
                </div>
            </div>
          
            <div class="form-group">
    <label class="control-label col-sm-2" for="pwd">Dirección:</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="dirección" name="dirección" placeholder="dirección" value=" <?php echo $dirección; ?>" required>
    </div>
  </div>



  <div class="form-group">
    <label class="control-label col-sm-2" for="pwd">Fecha Nacimiento:</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="fecha_nacimiento" name="fecha_nacimiento" placeholder="Fecha de Nacimiento" value=" <?php echo $fechanacimiento; ?>" required>
    </div>
  </div>



  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
      <button type="submit" class="btn btn-primary">Guardar</button>
    </div>
  </div>
</form>
      
      </div>
    </div>
   
  </div>
</div>

