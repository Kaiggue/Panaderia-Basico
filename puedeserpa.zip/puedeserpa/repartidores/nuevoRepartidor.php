
<?php 
include_once("../Connection.php");
//header('Content-Type: application/json; charset=utf-8');

if($_POST["operacion"]=="editar"){

$resu=Connection::runQuery("UPDATE `repartidor` SET `nombre`='".$_POST["nombre"]."',`telefono`='".$_POST["telefono"]."',`dirección`='".$_POST["dirección"]."',`fecha_nacimiento`='".$_POST["fecha_nacimiento"]."' WHERE `id_repartidor` ='".$_POST["id_repartidor"]."'");    


}
else
$resu=Connection::runQuery("INSERT INTO `repartidor`( `nombre`, `telefono`, `dirección` , `fecha_nacimiento`) VALUES ('".$_POST["Nombre"]."','".$_POST["Telefono"]."','".$_POST["Direccion"]."','".$_POST["FechadeNacimiento"]."')");


//echo "INSERT INTO `proveedor`( `nombre`, `direccion`, `cuit` , `telefono`, `tipo_proveedor`) VALUES ('$Nombre','".$_POST["Direccion"]."','".$_POST["Cuit"]."','".$_POST["Telefono"]."','".$_POST["TipoProveedor"]."')";


header('Location: ../principal.php?op=repartidor');
 ?>
 
 