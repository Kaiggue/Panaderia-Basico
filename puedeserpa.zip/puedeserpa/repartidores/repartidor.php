
<script>
 function eliminar(id_repartidor){

	 var confirma=confirm ("Desea eliminar al usuario "+ id_repartidor +"?") ;
	 if(confirma){
		window.location.href = "repartidores/eliminar.php?id_repartidor="+id_repartidor;

	 }
	// //href='eliminar.php?id=".$row["id"]."'
 }
 function editar(id_repartidor){
   window.location.href = "principal.php?op=editarRepartidor&id_repartidor="+id_repartidor;

}
// //href='eliminar.php?id=".$row["id"]."'







</script>

<?php

include_once("Connection.php");
?>

<div class="container">
  <h2>Lista de Repartidores</h2>
<div align="right"> <a  href="principal.php?op=Form" class="btn btn-primary"> <span class="glyphicon glyphicon-plus"></span> Nuevo </a></div>
<br/>
<table id="example" class="table table-striped table-bordered table-hover " style="width:100%">
    <thead>
      <tr>
        <th>Id Repartidores</th>
        <th>Nombre</th>
		<th>Telefono</th>
		<th>Direccion</th>
		<th>Fecha de Nacimiento</th>
		<th>Editar</th>
		<th>Eliminar</th>
      </tr>
    </thead>
	
    <tbody>
	<?php

   $request=Connection::runQuery("SELECT `id_repartidor`, `nombre`, `telefono`, `dirección`, `fecha_nacimiento` FROM `repartidor`");
	
	while ($row = mysqli_fetch_assoc($request)){
	      echo "<tr>";
	      echo " <td>". $row["id_repartidor"]." </td>";
		  echo " <td>". $row["nombre"]." </td>";
		  echo " <td>". $row["telefono"]." </td>";
		  echo " <td>". $row["dirección"]." </td>";
		  echo " <td>". $row["fecha_nacimiento"]." </td>";
		 
		
		  echo " <td width='2%'><a  href='#'  onClick= 'editar(". $row["id_repartidor"].")'  class='btn btn-info input-sm'><span class='glyphicon glyphicon-pencil'></span></a></td>";
		  echo "<td width='2%'><a  class='btn btn-danger input-sm' onClick= 'eliminar(". $row["id_repartidor"].")' ><span class='glyphicon glyphicon-trash'></span></a></td>";
		  
		  echo "</tr>";
		  
		//echo $row["usuario"]." ". $row["clave"]." ".$row["descripcion"]." ". $row["estado"]."<hr>";
	 
	}
		  
	
	  
?>
	


    </tbody>
  </table>
</div>


<?php


/*


$request=Connection::runQuery("SELECT usuarios.id, `usuario`, `clave`, tipo_usuarios.descripcion, `estado` FROM `usuarios`, tipo_usuarios WHERE usuarios.id_tipo=tipo_usuarios.id ");

while ($row = mysqli_fetch_assoc($request)){
	echo $row["usuario"]." ". $row["clave"]." ".$row["descripcion"]." ". $row["estado"]."<hr>";
 
}
*/

	  
?>



