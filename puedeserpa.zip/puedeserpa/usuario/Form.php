
<div class="container">
<br>
<br> 
  <div class="navbar navbar-default">
      <div class="panel-heading">Nuevo Usuario</div>
      <div class="panel-body">
      
      <form class="form-horizontal"  action="usuario/nuevoUsuario.php" method="POST">
  <div class="form-group">
    <label class="control-label col-sm-2" for="usuario">Usuario:</label>
    <div class="col-sm-10">
      <input type="usuario" class="form-control" id="usuario" name="usuario" placeholder="usuario" required>
    </div>
  </div>
  <div class="form-group">
    <label class="control-label col-sm-2" for="pwd">Password:</label>
    <div class="col-sm-10">
      <input type="Password" class="form-control" id="clave" name="clave" placeholder="clave" required>
    </div>
  </div>


  <div class="form-group">
    <label class="control-label col-sm-2" for="pwd" name="tipo">Tipo:</label>
    <div class="col-sm-10">
    <select class="form-control" name="tipo" required>
    <option></option> 
    <option value="1">Adminstrador</option>
    <option value="2">Operador</option>
  
  </select>
    </div>
  </div>





  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
      <div class="checkbox" value="estado" >
        <label> <input type="checkbox">Activo</label>
      </div>
    </div>
  </div>
  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
      <button type="submit" class="btn btn-primary">Enviar</button>
    </div>
  </div>
</form>
      
      
      
      </div>
    </div>

   
</div>

