
<?php 
include_once("../Connection.php");
//header('Content-Type: application/json; charset=utf-8');


$resu=Connection::runQuery("DELETE FROM `usuarios` WHERE `id` =".$_GET["id"]);

header('Location: ../principal.php?op=usuarios');


 ?>
 
 