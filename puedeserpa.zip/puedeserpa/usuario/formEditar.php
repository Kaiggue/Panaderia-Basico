
 <?php

include_once("Connection.php");
?>
<div class="container">
  
  <br>
  <div class="panel-group">
    <div class="panel panel-default">
      <div class="panel-heading">Editar Usuario</div>
      <div class="panel-body">
	  
	  <?php

    $request=Connection::runQuery("SELECT usuarios.id, `usuario`, `clave`, tipo_usuarios.descripcion, `estado` FROM `usuarios`, tipo_usuarios WHERE usuarios.id_tipo=tipo_usuarios.id  and usuarios.id = ".$_GET["id"]." order by  usuarios.id asc ");
	
	while ($row = mysqli_fetch_assoc($request)){
	
		$nombre=$row["usuario"];
		$clave=$row["clave"];
		$tipo=$row["descripcion"];
		$estado=$row["estado"];
		
		if($tipo=="administrador")
		$admin= "selected='selected'"; 
		if($tipo=="operario")
		$oper= "selected='selected'"; 
		
		
		if($estado=="1")
		$activo="checked='checked'";
	}
	
	?>
      
      <form class="form-horizontal" action="usuario/nuevoUsuario.php" method="post">
	  
	         <input name="operacion" type="hidden" value="editar" >
			 <input name="id" type="hidden" value="<?php echo $_GET["id"]; ?>" >
			 
            <div class="form-group">
                <label class="control-label col-sm-2" for="usuario">Usuario:</label>
                <div class="col-sm-10">
                <input type="text" class="form-control" id="usuario"  name="usuario" placeholder="Usuario"  value="<?php echo $nombre; ?>" required>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-sm-2" for="pwd">Password:</label>
                <div class="col-sm-10">
                <input type="password" class="form-control" id="clave" name="clave" placeholder="Password" value=" <?php echo $clave; ?>" required>
                </div>
            </div>


            <div class="form-group">
              <label class="control-label col-sm-2" for="tipo">Tipo:</label>
              <div class="col-sm-10">
                <select class="form-control"  required name="tipo">
                  <option></option>
                  <option  value="1"   <?php echo $admin; ?> >Administrador</option>
                  <option value="2"  <?php echo $oper; ?> >Operario</option>
				   
                  
                </select>
              </div>
          </div>

        
 <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                <div class="checkbox">
                    <label><input type="checkbox" <?php echo $estado; ?> > Activo:</label>
                </div>
                </div>
            </div>


            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
            </div>
 </form>
      
      </div>
    </div>
   
  </div>
</div>

