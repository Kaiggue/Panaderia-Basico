
<?php 
include_once("../Connection.php");
//header('Content-Type: application/json; charset=utf-8');
$usuario=$_POST["usuario"];

if($_POST["operacion"]=="editar"){

$resu=Connection::runQuery("UPDATE `usuarios` SET `usuario`='$usuario',`clave`='".$_POST["clave"]."',`id_tipo`=".$_POST["tipo"].",`estado`=1 where id =".$_POST["id"]);

}
else

 $resu=Connection::runQuery("INSERT INTO `usuarios`(`usuario`, `clave`, `id_tipo`, `estado`) VALUES ('$usuario','".$_POST["clave"]."',".$_POST["tipo"].",1)");


/* $resu=Connection::runQuery("INSERT INTO `usuarios`(`usuario`, `clave`, `id_tipo`, `estado`) VALUES ('$usuario','".$_POST["clave"]."',".$_POST["tipo"].",".$_POST["estado"].")");
 */

header('Location: ../principal.php?op=usuarios');
 ?>
 
 