<script>
	function eliminar(id) {

		var confirma = confirm("Desea eliminar al usuario " + id + "?");
		if (confirma) {
			window.location.href = "usuario/eliminar.php?id=" + id;

		}
		// //href='eliminar.php?id=".$row["id"]."'
	}

	function editar(id) {
		window.location.href = "principal.php?op=editarUsuario&id=" + id;

	}
	// //href='eliminar.php?id=".$row["id"]."'
</script>

<?php

include_once("Connection.php");
?>

<div class="container">
	<h2>Lista de usuarios</h2>
	<div align="right"> <a href="principal.php?op=nuevo" class="btn btn-primary"> <span class="glyphicon glyphicon-plus"></span> Nuevo </a></div>
	<br />
	<table id="example" class="table table-striped table-bordered table-hover " style="width:100%">
		<thead>
			<tr>
				<th>Id</th>
				<th>Nombre</th>
				<th>Clave</th>
				<th>Tipo</th>
				<th>Estado</th>
				<th>Editar</th>
				<th>Eliminar</th>
			</tr>
		</thead>

		<tbody>
			<?php

			$request = Connection::runQuery("SELECT usuarios.id, `usuario`, `clave`, tipo_usuarios.descripcion, `estado` FROM `usuarios`, tipo_usuarios WHERE usuarios.id_tipo=tipo_usuarios.id  order by  usuarios.id asc ");

			while ($row = mysqli_fetch_assoc($request)) {
				echo "<tr>";
				echo " <td>" . $row["id"] . " </td>";
				echo " <td>" . $row["usuario"] . " </td>";
				echo " <td>" . $row["clave"] . " </td>";
				echo " <td>" . $row["descripcion"] . " </td>";
				

				if ($row["estado"] == "1")
					echo " <td width='24'> <span class='glyphicon glyphicon-ok'></span></td>";
				else
					echo " <td width='24'><span class='glyphicon glyphicon-remove'></span></td>";

				echo " <td width='2%'><a  href='#'  onClick= 'editar(" . $row["id"] . ")'  class='btn btn-info input-sm'><span class='glyphicon glyphicon-pencil'></span></a></td>";
				echo "<td width='2%'><a  class='btn btn-danger input-sm' onClick= 'eliminar(" . $row["id"] . ")' ><span class='glyphicon glyphicon-trash'></span></a></td>";

				echo "</tr>";

				//echo $row["usuario"]." ". $row["clave"]." ".$row["descripcion"]." ". $row["estado"]."<hr>";

			}



			?>



		</tbody>
	</table>

			

</div>


<?php


/*


$request=Connection::runQuery("SELECT usuarios.id, `usuario`, `clave`, tipo_usuarios.descripcion, `estado` FROM `usuarios`, tipo_usuarios WHERE usuarios.id_tipo=tipo_usuarios.id ");

while ($row = mysqli_fetch_assoc($request)){
	echo $row["usuario"]." ". $row["clave"]." ".$row["descripcion"]." ". $row["estado"]."<hr>";
 
}
*/


?>