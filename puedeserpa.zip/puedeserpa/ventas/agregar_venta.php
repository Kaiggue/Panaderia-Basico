<?php
include_once("../Connection.php");

$request3 = Connection::runQuery("INSERT INTO `ventas` (`codcliente`, `total_ventas`, `fecha`) VALUES
 ('" . $_POST["idcliente"] . "','" . $_POST["resultado"] . "','" . $_POST["fecha"] . "')");

$request3 = Connection::runQuery("SELECT MAX(`cod_ventas`) FROM `ventas`");

// $id_compra=  Connection::runQuery(lastInsertId( `id_compra`));
// $id_compra = $row[`id_compra`];
$row = mysqli_fetch_array($request3);
$id_compra = $row[0];
echo $id_compra;

$compra = $_POST["compras"];
$pedidos = explode(";", $compra);


for ($i = 0; $i < count($pedidos); $i++) {

    $item = explode(",", $pedidos[$i]);

    $SQL = "INSERT INTO (`detalle_ventas`(`cod_ventas`,`id_productos`, `cantidad`, `subtotal`) VALUES ( " . $id_compra . "," . $item[0] . "," . $item[1] . "," . $item[2] . ")";
    echo $SQL;

    echo "<br>";

    echo "asd";



    $request3 = Connection::runQuery("INSERT INTO `detalle_ventas` (`cod_ventas`,`id_productos`, `cantidad`, `subtotal`) VALUES ( " . $id_compra . "," . $item[0] . "," . $item[1] . "," . $item[2] . ")");


    header('Location: ../principal.php?op=ventas');
}
